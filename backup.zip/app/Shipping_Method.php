<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Shipping_Method extends Model
{
    //
}
