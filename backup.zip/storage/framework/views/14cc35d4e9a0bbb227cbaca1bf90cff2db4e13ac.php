<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.slider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
    <div class="row">
        <h3>Popular items</h3>
    </div>
    <div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $productspopular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-lg-3 d-flex align-items-stretch">
      <div class="card w-100">
      <img class="card-img-top" src="<?php echo e(asset($product->ProductImages['file'])); ?>" alt="Card image cap">
        <div class="card-body">
          <h5 class="card-title"><?php echo e($product->product_name); ?></h5>
          <p class="card-text"><?php echo e(str_limit($product->product_description, 100)); ?></p>
        </div>
          <div class="card-footer">
            <a href="/description/<?php echo e($product->id); ?>" class="btn btn-primary">Visit</a>
            <p style="float: right">€ <?php echo e(number_format($product->price, 2,'.',',')); ?></p>
            <a href="<?php echo e(Route('wishlist.add', $product->id)); ?>" class="btn btn-lg btn-light">
              <img src="https://cdn3.iconfinder.com/data/icons/pyconic-icons-1-2/512/heart-outline-512.png" height="25" class="hello" alt=""/></a>
          </div>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p>No product</p>
  <?php endif; ?>
</div>

  <div class="row">
      <h3>Latest items</h3>
  </div>
  <div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $productslatest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="col-lg-3 d-flex align-items-stretch">
        <div class="card w-100">
        <img class="card-img-top" src="<?php echo e(asset($product->ProductImages['file'])); ?>" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title"><?php echo e($product->product_name); ?></h5>
            <p class="card-text"><?php echo e(str_limit($product->product_description, 100)); ?></p>
          </div>
            <div class="card-footer">
              <a href="/description/<?php echo e($product->id); ?>" class="btn btn-primary">Visit</a>
              <p style="float: right">€ <?php echo e(number_format($product->price, 2,'.',',')); ?></p>
              <a href="<?php echo e(Route('wishlist.add', $product->id)); ?>" class="btn btn-lg btn-light">
                <img src="https://cdn3.iconfinder.com/data/icons/pyconic-icons-1-2/512/heart-outline-512.png" height="25" class="hello" alt=""/></a>
            </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <p>No product</p>
    <?php endif; ?>
  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>