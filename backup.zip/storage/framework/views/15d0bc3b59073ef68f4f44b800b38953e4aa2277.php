<?php $__env->startSection('content'); ?>
	<div class="container main">
		<div class="row">
			<div class="col-md-12">
				<table id="cart" class="table table-hover table-condensed">
					<thead>
						<tr>
							<th style="width:10%">Product</th>
							<th style="width:40%"></th>
							<th style="width:10%">Price</th>
							<th style="width:8%">Quantity</th>
							<th style="width:22%" class="text-center">Subtotal</th>
							<th style="width:10%"></th>
						</tr>
					</thead>
					<tbody>
						<?php $__empty_1 = true; $__currentLoopData = $cartlines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td data-th="Product">
									<div class="row">

										
										<div class="col-sm-3 hidden-xs"><img src="<?php echo e(asset($cartline->product->ProductImages['file'])); ?>" width="100px" height="100px" alt="Card image cap"></div>

									</div>
								</td>
								<td data-th="Product">
									<h4 class="nomargin"><?php echo e($cartline->product->product_name); ?></h4>
								</td>
								<td data-th="Price">€<?php echo e(number_format($cartline->product->price,2,",",".")); ?></td>
								<td data-th="Quantity">
									<input type="number" class="form-control text-center" value="<?php echo e($cartline->amount); ?>" id="amount<?php echo e($cartline->product_id); ?>">
								</td>
								<td data-th="Subtotal" class="text-center subttl" value="<?php echo e(($cartline->product->price * $cartline->amount)); ?>">€<?php echo e(number_format($cartline->product->price * $cartline->amount,2,".",",")); ?></td>
								<td class="actions" data-th="">
									<button class="btn btn-info btn-sm updateCart" value="<?php echo e($cartline->product->id); ?>"><i class="fas fa-sync-alt"></i></button>
									<a href="<?php echo e(url('/cart/remove', $cartline->id)); ?>" class="btn btn-danger btn-sm"><i class="far fa-trash-alt"></i></button>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<tr><td>You have no products in your cart.</td></td>
						<?php endif; ?>
					</tbody>
					<tfoot>
						<tr>
							<td><a href="#" class="btn btn-primary"><i class="fa fa-angle-left"></i> Continue Shopping</a></td>
							<td colspan="3" class="hidden-xs"></td>
							<td class="hidden-xs text-center"><strong id="totalPrice"></strong></td>
							<td><a href="<?php echo e(url('/address')); ?>" class="btn btn-success btn-block">Checkout <i class="fa fa-angle-right"></i></a></td>
						</tr>
					</tfoot>
				</table>

			</div>
		</div>
	</div>
	<script>
	$(document).ready(function(){
		$('.updateCart').click(function() {
			var productid = $(this).attr('value');
			var amount = $('#amount' + productid).val();

			$.ajax({
				url: "<?php echo e(url('/cart/edit')); ?>",
				type: 'post',
				dataType: "application/json",
				data: {
					'_token': '<?php echo e(csrf_token()); ?>',
					'productid': productid,
					'amount': amount,
				},
			})
			$(document).ajaxStop(function(){
			    window.location.reload();
			});

		});
		var totalPrice = 0;
		$('.subttl').each(function(index) {
			// alert($('#subttl').attr('value'));
			// totalPrice = totalPrice + $('#subttl').val();
			totalPrice += Number($(this).attr('value'));
		});
		$('#totalPrice').text("Total € " + totalPrice.toFixed(2));
	});
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>