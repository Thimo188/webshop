

<?php $__env->startSection('content'); ?>
<div class="container main">
	<div class="row">
		<div class="col-md-12">
			<table width="100%">
				<tr>
					<th>Ordernummer</th>
					<th>Datum</th>
					<th>Prijs</th>
					<th>Status</th>
				</tr>
				<tr>
					<td><?php echo e($order->ordernumber); ?></td>
					<td><?php echo e($order->created_at); ?></td>
					<td></td>
					<td><?php echo e($order->status); ?></td>
				</tr>
			</table>
			<br /><br />
			<table width="100%">
				<tr>
					<th>&nbsp;</th>
					<th>Product</th>
				</tr>

				<?php $__currentLoopData = $orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><img src="<?php echo e(asset($details->product->ProductImages->file)); ?>"></td>
					<td><?php echo e($details->product->product_name); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>