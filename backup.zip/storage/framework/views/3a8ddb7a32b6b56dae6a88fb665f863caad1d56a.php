<?php $__env->startSection('content'); ?>
<!-- <div class="container mt-5" id="product-section">
  <div class="row">
   <div class="col-md-4">
     <div class="card" style="width: 18rem;">
       <img class="card-img-top" src="images/description/eye.jpg" alt="Card image cap">
       <div class="card-body">
         <h5 class="card-title">Card title</h5>
         <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
         <a href="#" class="btn btn-lg btn-primary">Add to Cart</a>
         <a href="#" class="btn btn-lg btn-danger"><i class="fas fa-trash-alt"></i></a>
         </button>
       </div>
     </div>
   </div>
 </div>
</div> -->
<div class="container mt-5" id="product-section">
  <div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $wished; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishlistitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="col-md-4">

<!-- <?php echo e($wishlistitem->User()->first()->name); ?> -->
      <div class="card" style="width: 18rem">
      <img class="card-img-top" src="<?php echo e($wishlistitem->Product()->first()->ProductImages()->first()->file); ?>" alt="Card image cap">
        <div class="card-body">
          <h5 class="card-title"><?php echo e($wishlistitem->Product()->first()->product_name); ?></h5>
          <p class="card-text"><?php echo e($wishlistitem->Product()->first()->product_description); ?></p>
          <a href="<?php echo e(url('/description', $wishlistitem->product_id)); ?>" class="btn btn-lg btn-primary">Go to this product</a>
          <a href="<?php echo e(route('wishlist.destroy', $wishlistitem->id)); ?>" class="btn btn-lg btn-danger"><i class="fas fa-trash-alt"></i></a>
<!-- "<?php echo e(route('wishlist.show', [$wishlistitem->id])); ?>" -->
        </div>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p>No favourites yet</p>
  </div>

    <?php endif; ?>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>