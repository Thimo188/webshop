<h1>Hi,</h1><br/>
<br/>
<p>Welcome <?php echo e($user->name); ?> at <strong>MUZEN</strong></p>
<p>Click <a href="<?php echo e(url('/')); ?>">here</a> to login to your account.</p><br/>
<br/>
Kind regards,<br/>
<br/>
Team Muzen
