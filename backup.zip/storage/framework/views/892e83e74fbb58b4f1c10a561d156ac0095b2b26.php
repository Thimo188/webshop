<?php if($message = Session::get('success')): ?>
    <section class="padding-3" id="flash-message" data-closable>
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="small-12 cell">
                    <div class="success callout">
                        <p><?php echo e($message); ?></p>
                        <button class="close-button" aria-label="Dismiss alert" type="button" data-close>
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>


<?php if($message = Session::get('error')): ?>
    <section class="padding-3" id="flash-message" data-closable>
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="small-12 cell">
                    <div class="alert callout">
                        <p><?php echo e($message); ?></p>
                        <button class="close-button" aria-label="Dismiss alert" type="button" data-close>
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>


<?php if($message = Session::get('warning')): ?>
    <section class="padding-3" id="flash-message" data-closable>
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="small-12 cell">
                    <div class="warning callout">
                        <p><?php echo e($message); ?></p>
                        <button class="close-button" aria-label="Dismiss alert" type="button" data-close>
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>


<?php if($message = Session::get('info')): ?>
    <section class="padding-3" id="flash-message" data-closable>
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="small-12 cell">
                    <div class="primary callout">
                        <p><?php echo e($message); ?></p>
                        <button class="close-button" aria-label="Dismiss alert" type="button" data-close>
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>


<?php if($errors->any()): ?>
    <section class="padding-3" id="flash-message" data-closable>
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="small-12 cell">
                    <div class="alert callout">
                        <ul class="no-bullet">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button class="close-button" aria-label="Dismiss alert" type="button" data-close>
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
