<?php $__env->startSection('content'); ?>
<div class="card-body">
	<?php if($errors->any()): ?>
	<div class="alert alert-danger">
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div><br />
	<?php endif; ?>

</div>
</div>
</div>

<div class="container main">
	<div class="row">
		<div class="col-md-6">
			<h4 class="mb-3">Billing address</h4>
		</div>
		<div class="col-md-7">
			<form method="post" action="<?php echo e(route('address.store')); ?>" id="address">
				<?php echo csrf_field(); ?>
				<div class="form-group">
					<div class="form-group">
						<label for="FirstName">First Name:</label>
						<input type="text" class="form-control" name="FirstName" required />
					</div>
					<div class="form-group">
						<label for="LastName">Last Name:</label>
						<input type="text" class="form-control" name="LastName" required />
					</div>
					<label for="name">Streetname:</label>
					<input type="text" class="form-control" name="streetname" required />
					<div>
						<label for="country">Land:</label>
						<select name="country" class="form-control">
							<?php $__empty_1 = true; $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<option value="none">No countries available</option>
							<?php endif; ?>
						</select>
					</div>
					<div class="form-group">
						<label for="place">Place:</label>
						<input type="text" class="form-control" name="place" required />
					</div>
					<div class="form-group">
						<label for="quantity">Zipcode:</label>
						<input type="text" class="form-control" name="zipcode" required />
					</div>
					<hr class="mb-4">

					<button type="submit" class="btn btn-primary">Continue to checkout</button>
			</form>

		</div>


	</div>
	<div class="col-md-4 offset-md-1">
		<b>Order</b>
		<table width="100%" class="table">
			<tr>
				<th width="50%">Product</th>
				<th>&nbsp;</th>
				<th width="28%">Qty</th>
				<th>Prijs</th>
			</tr>
			<?php $__currentLoopData = $cartlines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($line->Product->product_name); ?></td>
				<td></td>
				<td><?php echo e(number_format($line->amount,2,",",".")); ?>

				<td class="subttl" value="<?php echo e($line->Product->price * $line->amount); ?>"><?php echo e(number_format($line->Product->price * $line->amount,2,",",".")); ?>

			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>Excl. BTW:</td>
				<td id="exbtw">1</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>Incl. BTW:</td>
				<td id="inbtw">1</td>
			</tr>
		</table>
	</div>
</div>
</div>
<script>
	var totalPrice = 0;
	$('.subttl').each(function(index) {
		totalPrice += Number($(this).attr('value'));
	});
	$('#exbtw').text((totalPrice * 0.79).toFixed(2));
	$('#inbtw').text(totalPrice.toFixed(2));
	// $('#totalPrice').val(totalPrice.toFixed(2));
	// $('#address').submit(function(e) {
	// 	var formdata = $(this).serializeArray();
	// 	e.preventDefault();
	// 	$.ajax({
	// 		url: "<?php echo e(route('payments.create')); ?>",
	// 		method: 'post',
	// 		data: formdata,
	// 		success: function(result) {
	// 			console.log(result);
	// 		}
	// 	})
	// 	$('#price').val();
	// });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>