<?php $__env->startSection('content'); ?>
<div class="container main">
	<div class="row">
		<div class="col-md-12">
			<table width="100%">
				<tr>
					<th>Ordernummer</th>
					<th>Datum</th>
					<th>Prijs</th>
					<th>Status</th>
				</tr>
				<?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<tr>
					<td><?php echo e($order->ordernumber); ?></td>
					<td><?php echo e($order->created_at); ?></td>
					<td></td>
					<td><?php echo e($order->status); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<tr>
					<td colspan=4>No orders have been found</td>
				</tr>
				<?php endif; ?>
			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidemenu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>